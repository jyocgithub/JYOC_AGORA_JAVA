package mario_ejercicio6;

public class PruebaVideojuego {
    public static void main(String[] args) {
        Videojuego v1 = new Videojuego("The Crew", 76,"Medio", "Carreras", "Microsoft");

        System.out.println(v1.getTitulo());
        System.out.println(v1.getCompañia());
        System.out.println(v1.getGenero());
        System.out.println(v1.getHorasestimadas());
        System.out.println(v1.getNiveldif());


        Videojuego v2 = new Videojuego("The Crew 2", 76,"Medio", "Carreras", "Microsoft");
        Videojuego v3 = new Videojuego("Fortnite", 346,"Medio", "Aventura", "Microsoft");
        Videojuego v4 = new Videojuego("The Flag", 11,"Alto", "Aventura", "Microsoft");
        Videojuego v5 = new Videojuego("Absentia", 534,"Medio", "Carreras", "Microsoft");

        Videojuego[] arrayvideojuegos  = new Videojuego[5];
        arrayvideojuegos[0] = v1;
        arrayvideojuegos[1] = v2;
        arrayvideojuegos[2] = v3;
        arrayvideojuegos[3] = v4;
        arrayvideojuegos[4] = v5;

        System.out.println("-------------------");
        for (int i = 0; i < arrayvideojuegos.length ; i++) {
            System.out.println(arrayvideojuegos[i].getTitulo());
        }
    }
}
