package mario_ejercicio6;

public class Videojuego {
    private String titulo;
    private int horasestimadas = 10;
    private String niveldif;
    private String genero;
    private String compañia;

    public Videojuego(String titulo, int horasestimadas) {
        this.titulo = titulo;
        this.horasestimadas = horasestimadas;
    }

    public Videojuego(String titulo, int horasestimadas, String niveldif, String genero, String compañia) {
        this.titulo = titulo;
        this.horasestimadas = horasestimadas;
        this.niveldif = niveldif;
        this.genero = genero;
        this.compañia = compañia;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getHorasestimadas() {
        return horasestimadas;
    }

    public void setHorasestimadas(int horasestimadas) {
        this.horasestimadas = horasestimadas;
    }

    public String getNiveldif() {
        return niveldif;
    }

    public void setNiveldif(String niveldif) {
        this.niveldif = niveldif;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getCompañia() {
        return compañia;
    }

    public void setCompañia(String compañia) {
        this.compañia = compañia;
    }
}
