package mario_ejercicio7;

public class PruebaLibro {
    public static void main(String[] args) {
        Libro libroA = new Libro("23443KKNS", "IT", "Stephen King", 1210);
        Libro libroB = new Libro("543533DDS", "El Quijote", "Cervantes", 3211);

        System.out.println(libroA.mostrarInfo());
        System.out.println(libroB.mostrarInfo());

        libroA.cualTieneMasPaginas(libroB);

        Libro.dejarLibrosEnBiblioteca();


    }


}
