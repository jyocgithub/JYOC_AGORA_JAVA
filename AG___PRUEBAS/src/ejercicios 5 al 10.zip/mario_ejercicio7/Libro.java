package mario_ejercicio7;

public class Libro {
    private String ISBN;
    private String titulo;
    private String autor;
    private int numpaginas;

    public Libro(String ISBN, String titulo, String autor, int numpaginas) {
        this.ISBN = ISBN;
        this.titulo = titulo;
        this.autor = autor;
        this.numpaginas = numpaginas;
    }

    public String mostrarInfo() {
        return "El libro con ISBN " + ISBN +
                " creado por el autor " + autor +
                " tiene " + numpaginas + " páginas";
    }


    public static void dejarLibrosEnBiblioteca(){
        System.out.println("Todos los libros estan en la biblioteca");
    }

    public void cualTieneMasPaginas(Libro l1){
        if(l1.getNumpaginas() > this.getNumpaginas()){
            System.out.println("el libro " + l1.getTitulo() +" tiene mas páginas que el libro "+this.getTitulo());
        }else  if(this.getNumpaginas() > l1.getNumpaginas()){
            System.out.println("el libro " + this.getTitulo() +" tiene mas páginas que el libro "+l1.getTitulo());
        }else{
            System.out.println("el libro " + this.getTitulo() +" tiene las mismas páginas que el libro "+l1.getTitulo());
        }
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getNumpaginas() {
        return numpaginas;
    }

    public void setNumpaginas(int numpaginas) {
        this.numpaginas = numpaginas;
    }
}
