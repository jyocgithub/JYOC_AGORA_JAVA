package mario_ejercicio8;

public class PruebaFecha {
    public static void main(String[] args) {

        Fecha f1 = new Fecha(29,2,2000);

        Fecha f2  =     f1.diaSiguiente(f1);
        System.out.println(f2);

    }

}
