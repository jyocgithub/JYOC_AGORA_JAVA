package mario_ejercicio8;

public class Fecha {
    private int dia;
    private int mes;
    private int anio;

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public Fecha(int dia, int mes) {
        this.dia = dia;
        this.mes = mes;
    }


    private boolean fechacorrecta(Fecha f) {
        if (f.getMes() < 0 || f.getMes() > 12) {
            return false;
        }

        if (f.getDia() < 1) {
            return false;
        }

        if (f.getMes() == 1 || f.getMes() == 3 || f.getMes() == 5 || f.getMes() == 7 || f.getMes() == 8 || f.getMes() == 10 || f.getMes() == 12) {
            if (f.getDia() > 31) {
                return false;
            }
        }

        if (f.getMes() == 4 || f.getMes() == 6 || f.getMes() == 9 || f.getMes() == 11) {
            if (f.getDia() > 30) {
                return false;
            }
        }

        if (f.getMes() == 2 && f.getDia() > 29) {
            return false;
        }

        if (f.getMes() == 2 && f.getDia() == 29) {
            if (esBisiesto(f.getAnio())) {
                return true;
            } else {
                return false;
            }

        }

        return true;

    }

    public Fecha diaSiguiente(Fecha f) {

        if (fechacorrecta(f)) {

            int dia = f.getDia();
            f.setDia(dia + 1);

            // tras incrementar el dia,
            // vemos si nos hemos pasado de dia a uno mas de los que tiene el mes
            if (f.getMes() == 1 || f.getMes() == 3 || f.getMes() == 5 || f.getMes() == 7 || f.getMes() == 8 || f.getMes() == 10 || f.getMes() == 12) {
                if (f.getDia() > 31) {
                    f.setDia(1);
                    int mes = f.getMes();
                    f.setMes(mes + 1);
                }
            }

            if (f.getMes() == 4 || f.getMes() == 6 || f.getMes() == 9 || f.getMes() == 11) {
                if (f.getDia() > 30) {
                    f.setDia(1);
                    int mes = f.getMes();
                    f.setMes(mes + 1);
                }
            }

            if (esBisiesto(f.getAnio())) {
                if (f.getMes() == 2 && f.getDia() > 29) {
                    f.setDia(1);
                    f.setMes(3);
                }
            } else {
                if (f.getMes() == 2 && f.getDia() > 28) {
                    f.setDia(1);
                    f.setMes(3);
                }
            }

            // tras incrementar el mes,
            // vemos si nos hemos pasado de mes a mas alla de diciembre
            if (f.getMes() > 12) {
                f.setMes(1);
                int anio = f.getAnio();
                f.setAnio(anio + 1);
            }


        }


        return f;
    }


    public boolean esBisiesto(int anio) {
        if ((anio % 4 == 0 && anio % 100 != 0) || (anio % 100 == 0 && anio % 400 == 0)) {
            return true;
        } else {
            return false;
        }
    }


    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }


    @Override
    public String toString() {
        return "Fecha{" +
                "dia=" + dia +
                ", mes=" + mes +
                ", anio=" + anio +
                '}';
    }
}
