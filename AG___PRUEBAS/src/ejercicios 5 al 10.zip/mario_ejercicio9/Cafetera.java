package mario_ejercicio9;

public class Cafetera {

    private int capacidadMaxima;
    private int cantidadActual;

    public Cafetera() {
        this.cantidadActual = 0;
        this.capacidadMaxima = 1000;

    }

    public Cafetera(int capacidadMaxima) {

        this.cantidadActual = this.capacidadMaxima;
    }


    public Cafetera(int capacidadMaxima, int cantidadActual) {
        this.capacidadMaxima = capacidadMaxima;
        this.cantidadActual = cantidadActual;
        if (this.cantidadActual > this.capacidadMaxima) {
            this.cantidadActual = this.capacidadMaxima;
        }
    }

    public void llenarCafetera() {
        this.cantidadActual = this.capacidadMaxima;
    }

    public void vaciarCafetera() {
        this.cantidadActual = 0;
    }

    public void servirTaza(int cantidadTaza) {
        if (cantidadActual - cantidadTaza < 0) {
            System.out.println("Se sirve solo " + cantidadActual);
            cantidadActual = 0;
        } else {
            System.out.println("Se sirve  " + cantidadTaza);
            cantidadActual = cantidadActual - cantidadTaza;
        }
    }

    public void agregarCafe(int cantidad) {
        cantidadActual = cantidadActual + cantidad;
        if (cantidadActual > capacidadMaxima) {
            cantidadActual = capacidadMaxima;
        }
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public void setCantidadActual(int cantidadActual) {
        this.cantidadActual = cantidadActual;
    }
}
