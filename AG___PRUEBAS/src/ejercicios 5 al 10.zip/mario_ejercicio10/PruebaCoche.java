package mario_ejercicio10;

public class PruebaCoche {

    public static void main(String[] args) {

        Motor m = new Motor();

        Rueda r1 = new Rueda();
        Rueda r2 = new Rueda();
        Rueda r3 = new Rueda();
        Rueda r4 = new Rueda();

        Ventana v1 = new Ventana();
        Ventana v2 = new Ventana();

        Puerta p1 = new Puerta(v1);
        Puerta p2 = new Puerta(v2);

        Coche c1 = new Coche(m, r1, r2, r3, r4, p1, p2);

        c1.arrancarCoche();

    }

}
