package mario_ejercicio10;

public class Motor {


    public void arrancar() {
        System.out.println("motor arrancado");
    }
    public void apagar() {
        System.out.println("motor apagado");
    }

}
