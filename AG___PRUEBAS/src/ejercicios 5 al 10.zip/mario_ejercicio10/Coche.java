package mario_ejercicio10;

public class Coche {

    Motor motor;

    Rueda rueda1,rueda2,rueda3,rueda4;

    Puerta puerta1,puerta2;


    public Coche(Motor motor, Rueda rueda1, Rueda rueda2, Rueda rueda3, Rueda rueda4, Puerta puerta1, Puerta puerta2) {
        this.motor = motor;
        this.rueda1 = rueda1;
        this.rueda2 = rueda2;
        this.rueda3 = rueda3;
        this.rueda4 = rueda4;
        this.puerta1 = puerta1;
        this.puerta2 = puerta2;
    }

    public void arrancarCoche(){
        motor.arrancar();
    }
    public void apagarCoche(){
        motor.apagar();
    }


    public void subirVentanas(){
        puerta1.ventana.abrir();
        puerta2.ventana.abrir();
    }




}
