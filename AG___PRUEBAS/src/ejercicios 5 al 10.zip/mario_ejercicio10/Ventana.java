package mario_ejercicio10;

public class Ventana {


    public void abrir() {
        System.out.println("ventana abierta");
    }
    public void cerrar() {
        System.out.println("vengana cerrada");
    }


}
