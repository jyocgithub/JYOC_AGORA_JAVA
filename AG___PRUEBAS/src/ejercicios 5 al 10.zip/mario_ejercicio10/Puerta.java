package mario_ejercicio10;

public class Puerta {

    Ventana ventana;

    public Puerta(Ventana ventana) {
        this.ventana = ventana;
    }

    public void abrir() {
        System.out.println("puerta abierta");
    }
    public void cerrar() {
        System.out.println("puerta cerrada");
    }

}
