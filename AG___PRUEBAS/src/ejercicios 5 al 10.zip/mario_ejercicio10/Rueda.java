package mario_ejercicio10;

public class Rueda {


    public void inflar() {
        System.out.println("rueda inflada");
    }
    public void desinflar() {
        System.out.println("rueda desinfada");
    }

}
