package mario_ejercicio5;

public class PruebaPersona {
    public static void main(String[] args) {
        Persona p1 = new Persona("Mario",23, 'H');
        Persona p2 = new Persona("Ana", 20,'M', 52, 1.52 );

        System.out.println(p2.calcularIMC());
        if(p2.esMayorDeEdad()){
            System.out.println("mayor de edad");
        }else{
            System.out.println("menor de edad");

        };


        System.out.println(p2.getDNI());
    }
}
